"""Funciones puras de limpieza (Semana 1).

Principios:
- Funciones puras: entrada -> salida (sin I/O dentro).
- Transformaciones pequeñas y testeables.
"""

from __future__ import annotations

import re
from typing import Dict, Iterable

import pandas as pd

from .config import DATE_COLUMNS, EXPECTED_COLUMNS


_MONTH_MAP = {
    # abreviaturas comunes en español usadas en Colombia
    "ene": 1, "feb": 2, "mar": 3, "abr": 4, "may": 5, "jun": 6,
    "jul": 7, "ago": 8, "sep": 9, "set": 9, "oct": 10, "nov": 11, "dic": 12,
}


def normalize_column_names(columns: Iterable[str]) -> list[str]:
    """Normaliza nombres: minúsculas, sin espacios, sin guiones, sin trailing underscores."""
    out = []
    for c in columns:
        c2 = c.strip().lower()
        c2 = re.sub(r"\s+", "_", c2)
        c2 = c2.replace("-", "_")
        c2 = re.sub(r"_+$", "", c2)  # quita underscores al final
        out.append(c2)
    return out


def drop_all_na_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Elimina columnas vacías (típicas de CSV con separadores extra)."""
    keep = [c for c in df.columns if not df[c].isna().all()]
    return df.loc[:, keep].copy()


def parse_spanish_dmy(series: pd.Series) -> pd.Series:
    """Parsea fechas tipo '3-ene-2023' a datetime64[ns]. Mantiene NaT si falla."""
    def _parse_one(x):
        if pd.isna(x):
            return pd.NaT
        s = str(x).strip()
        if s == "":
            return pd.NaT
        # formatos posibles: 3-ene-2023, 03-ene-2023
        m = re.match(r"^(\d{1,2})-([A-Za-zñÑ]{3})-(\d{4})$", s)
        if not m:
            return pd.NaT
        day = int(m.group(1))
        mon = m.group(2).lower()
        year = int(m.group(3))
        month = _MONTH_MAP.get(mon)
        if month is None:
            return pd.NaT
        return pd.Timestamp(year=year, month=month, day=day)

    return series.map(_parse_one)


def coerce_types(df: pd.DataFrame) -> pd.DataFrame:
    """Ajusta tipos principales sin perder información."""
    out = df.copy()

    # Edad
    if "edad" in out.columns:
        out["edad"] = pd.to_numeric(out["edad"], errors="coerce").astype("Int64")

    # Divipola suele ser código (mejor como string)
    if "cod_divipola" in out.columns:
        out["cod_divipola"] = out["cod_divipola"].astype("string")

    # Categorías a string normalizado
    for c in ["ciudad", "dpto", "sexo", "tip_ss", "per_etn", "res_biops9", "grad_histo"]:
        if c in out.columns:
            out[c] = out[c].astype("string").str.strip().str.lower()

    return out


def parse_date_columns(df: pd.DataFrame, date_cols: Iterable[str] = DATE_COLUMNS) -> pd.DataFrame:
    out = df.copy()
    for c in date_cols:
        if c in out.columns:
            out[c] = parse_spanish_dmy(out[c])
    return out


def enforce_expected_columns(df: pd.DataFrame, expected: Iterable[str] = EXPECTED_COLUMNS) -> pd.DataFrame:
    """Selecciona y ordena columnas esperadas; ignora extras."""
    expected = list(expected)
    missing = [c for c in expected if c not in df.columns]
    if missing:
        raise ValueError(f"Faltan columnas esperadas: {missing}")
    return df.loc[:, expected].copy()


def clean_pipeline(df: pd.DataFrame) -> pd.DataFrame:
    """Pipeline de limpieza (composición de funciones puras)."""
    out = df.copy()
    out.columns = normalize_column_names(out.columns)
    out = drop_all_na_columns(out)
    # renombrar variables con underscore final en el raw
    out = out.rename(columns={
        "edad_": "edad",
        "sexo_": "sexo",
        "tip_ss_": "tip_ss",
        "per_etn_": "per_etn",
        "fec_con_": "fec_con",
        "ini_sin_": "ini_sin",
    })
    out = parse_date_columns(out)
    out = coerce_types(out)
    out = enforce_expected_columns(out)
    return out
