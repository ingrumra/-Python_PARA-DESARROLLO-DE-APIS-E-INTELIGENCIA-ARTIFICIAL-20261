# Semana 1 — Limpieza básica y modular (Pandas)

Dataset: `cancer_mama_piii_2023_raw.csv` (separador `;` + columnas vacías por `;` finales).

## Objetivo
- Seleccionar dataset
- Limpieza básica en Pandas
- Modularizar en funciones puras (en `src/cleaning.py`)

## Cómo correr

### 1) Crear entorno
```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/Mac
source .venv/bin/activate

pip install -r requirements.txt
```

### 2) Ejecutar limpieza
```bash
python scripts/run_cleaning.py
```

Salida:
- `data/processed/cancer_mama_piii_2023_clean.csv`

### 3) (Opcional) correr tests
```bash
pytest -q
```

## Notas de limpieza (decisiones)
- Se eliminan columnas completamente vacías (`Unnamed:*`).
- Se normalizan nombres y se renombran campos con sufijo `_`.
- Fechas tipo `3-ene-2023` se parsean a datetime.
- `cod_divipola` se deja como string para preservar códigos.
