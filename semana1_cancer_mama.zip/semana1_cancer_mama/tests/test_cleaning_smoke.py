import pandas as pd

from src.cleaning import clean_pipeline


def test_clean_pipeline_smoke():
    raw = pd.DataFrame({
        "codigo_sspm": [1],
        "fec_not": ["3-ene-2023"],
        "cod_divipola": [11001],
        "ciudad": ["Bogotá"],
        "dpto": ["Bogotá D.C."],
        "edad_": [55],
        "sexo_": ["Femenino"],
        "tip_ss_": ["Contributivo"],
        "per_etn_": ["Otro"],
        "fec_con_": ["2-ene-2023"],
        "ini_sin_": [pd.NA],
        "fec_pro_co": [pd.NA],
        "fec_res_bi": [pd.NA],
        "res_biops9": ["Positiva"],
        "grad_histo": ["II"],
        "fecha_corte": ["31-dic-2023"],
        "fecha_reporte_web": ["1-ene-2024"],
        "Unnamed: 99": [pd.NA],
    })
    out = clean_pipeline(raw)
    assert out.shape[0] == 1
    assert "edad" in out.columns
    assert str(out.loc[0, "fec_not"].date()) == "2023-01-03"
