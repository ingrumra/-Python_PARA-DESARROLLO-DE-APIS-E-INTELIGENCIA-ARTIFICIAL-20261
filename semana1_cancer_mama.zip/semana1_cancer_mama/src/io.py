"""Entrada/salida (I/O) separada de la limpieza."""

from __future__ import annotations

import pandas as pd


def read_raw_semicolon_csv(path: str) -> pd.DataFrame:
    """Lee CSV separado por ';' con posibles ';' finales que crean columnas vacías."""
    return pd.read_csv(path, sep=';', engine='python')


def write_csv(df: pd.DataFrame, path: str) -> None:
    df.to_csv(path, index=False)
