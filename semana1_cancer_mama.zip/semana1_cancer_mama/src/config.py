"""Configuración del proyecto (Semana 1)."""

EXPECTED_COLUMNS = [
    "codigo_sspm",
    "fec_not",
    "cod_divipola",
    "ciudad",
    "dpto",
    "edad",
    "sexo",
    "tip_ss",
    "per_etn",
    "fec_con",
    "ini_sin",
    "fec_pro_co",
    "fec_res_bi",
    "res_biops9",
    "grad_histo",
    "fecha_corte",
    "fecha_reporte_web",
]

DATE_COLUMNS = [
    "fec_not",
    "fec_con",
    "ini_sin",
    "fec_pro_co",
    "fec_res_bi",
    "fecha_corte",
    "fecha_reporte_web",
]
